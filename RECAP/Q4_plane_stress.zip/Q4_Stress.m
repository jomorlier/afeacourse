function [ Se ] = Q4_Stress( E,C,xy,v,TYPE,displacement,NumEle)
% Stresses for each element [Se]=[D][B]{d}
%   [B] is the matrix that relates strains to displacments
%   E is modulus of elastcity of the element
%   v is Poisson's ratio
%   displacement are the nodal dispalcements

Se(1:NumEle,1:3,1:4) = 0;
dtemp(8,1) = 0;

b11(4) = 0;
b22(4) = 0;
b32(4) = 0; 


for iele = 1:NumEle
    
    switch TYPE
        case 1
            D = E(iele)/(1-v^2)*[1    v     0;
                               v    1     0;
                               0    0 (1-v)/2]; % plain stress
        case 2
            D = E(iele)/(1+v)/(1-2*v)*[1-v   v    0;
                                      v   1-v   0;
                                      0    0  .5-v];  % plain strain
    end
    
             
    xeT = xy(C(iele,:),1).';
    yeT = xy(C(iele,:),2).';
    
    for inode = 1:4  
        index1 = 2*C(iele,inode)-1;
        index2 = 2*C(iele,inode);
        dtemp(2*inode-1,1)= displacement(index1,1);
        dtemp(2*inode  ,1)= displacement(index2,1);
    end

    is = 0;
    % s-t corrdinates of four nodes in element space
    nxy = [ -1 -1;
             1 -1;
             1  1;
            -1 -1];
    
    for inode = 1:4
        
        s_cor = nxy(inode,1);
        t_cor = nxy(inode,2);
            
        dnds = [ t_cor/4 - 1/4; 1/4 - t_cor/4; t_cor/4 + 1/4; - t_cor/4 - 1/4];
        dndt = [ s_cor/4 - 1/4; -s_cor/4 - 1/4; s_cor/4 + 1/4; 1/4 - s_cor/4];

        J = [(xeT*dnds) (yeT*dnds); (xeT*dndt) (yeT*dndt)];
        detJ = det(J);

        dxds = xeT*dnds;
        dxdt = xeT*dndt;
        dyds = yeT*dnds;
        dydt = yeT*dndt;

        b11(4) = 0;
        b22(4) = 0;
        b32(4) = 0; 

        for im = 1:4
            b11(im) = dydt*dnds(im)-dyds*dndt(im);
            b22(im) = dxds*dndt(im)-dxdt*dnds(im);
            b32(im) = dydt*dnds(im)-dyds*dndt(im);
            iim = 2*im-1;

            B(1:3,iim:iim+1) = [ b11(im)    0   ;
                                 0     b22(im);
                               b22(im) b32(im)];    
        end

        is = is+1;

        Se(iele,:,is) = D*B*dtemp/detJ; 
        
    end
             
end

