%Q4QUAD

%Gaussian trianular points and weights

clear all

gpts = [0.0000000 -0.5773503 0.5773503 0.0000000 -0.7745967 0.7745967 -0.3399810 -0.8611363 0.3399810 0.8611363 0.0000000 -0.5384693 -0.9061798 0.5384693 0.9061798 -0.2386102 -0.6612094 -0.9324695 0.2386102 0.6612094 0.9324695 0.0000000 0.4058452 -0.4058452 -0.7415312 0.7415312 -0.9491079 0.9491079];

gwts = [2.0000000 1.0000000 1.0000000 0.8888889 0.5555556 0.5555556 0.6521452 0.3478549 0.6521452 0.3478549 0.5688889 0.4786287 0.2369269 0.4786287 0.2369269 0.4679139 0.3607616 0.1713245 0.4679139 0.3607616 0.1713245 0.4179592 0.3818301 0.3818301 0.2797054 0.2797054 0.1294850 0.1294850];

%User inputs

prompt1 = 'Enter X values as one dimensional array: ';
xeT = [ 3 5 5 3 ];
prompt2 = 'Enter Y values as one dimensional array: ';
yeT = [ 2 2 4 4 ];

X = ['xeT = ',num2str(xeT)];
Y = ['yeT = ',num2str(yeT)];
disp(X);
disp(Y);

prompt3 = 'Enter the number of Gaussian Quadrature points you wish to use: ';
npts = 2;

Num = ['Number of Gaussian Quadrature Points = ',num2str(npts)];
disp(Num);

%Calculating ke

if npts == 1
    gptss = gpts(1);
    gwtss = gwts(1);
elseif npts == 2
    gptss = gpts(2:3);
    gwtss = gwts(2:3);
elseif npts == 3
    gptss = gpts(4:6);
    gwtss = gwts(4:6);
elseif npts == 4
    gptss = gpts(7:10);
    gwtss = gwts(7:10);
elseif npts == 5
    gptss = gpts(11:15);
    gwtss = gwts(11:15);
elseif npts == 6
    gptss = gpts(16:21);
    gwtss = gwts(16:21);
else
    gptss = gpts(22:28);
    gwtss = gwts(22:28);
end

syms s t

N1 = (1-s)*(1-t)/4;
N2 = (1+s)*(1-t)/4;
N3 = (1+s)*(1+t)/4;
N4 = (1-s)*(1+t)/4;

N = [ N1; N2; N3; N4 ];

dnds = [ t/4 - 1/4; 1/4 - t/4; t/4 + 1/4; - t/4 - 1/4];
dndt = [ s/4 - 1/4; - s/4 - 1/4; s/4 + 1/4; 1/4 - s/4];

J = [(xeT*dnds) (yeT*dnds); (xeT*dndt) (yeT*dndt)];
detJ = det(J);

dxds = xeT*dnds;
dxdt = xeT*dndt;
dyds = yeT*dnds;
dydt = yeT*dndt;

for i = 1:4
    b11(i) = dydt*dnds(i)-dyds*dndt(i);
    b22(i) = dxds*dndt(i)-dxdt*dnds(i);
    b32(i) = dydt*dnds(i)-dyds*dndt(i);
    ii = 2*i-1;
    B(1:3,ii:ii+1) = [ b11(i)    0  ;
                         0    b22(i);
                       b22(i) b32(i)];    
end

B = B/detJ;

E = 30*10^6;
v = 0.25;

TYPE = 1;
switch TYPE
    case 1
        D = E/(1-v^2)*[1    v     0;
                           v    1     0;
                           0    0 (1-v)/2]; % plain stress
    case 2
        D = E/(1+v)/(1-2*v)*[1-v   v    0;
                                  v   1-v   0;
                                  0    0  .5-v];  % plain strain
end

ke = B.'*D*B;

Ke = 0;

for i = 1:npts
    for j = 1:npts
        Ke = Ke + subs(ke,[s, t],[gptss(i), gptss(j)])*gwtss(i)*gwtss(j); 
    end
end

Ke = vpa(Ke,6);

disp(Ke);