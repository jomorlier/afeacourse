%
% symbolic integration of the [B] matrix for Q4 element
%

syms h b x y E v t
format shortEng

B = [ -(h-y)     0    h-y      0   h+y    0 -(h+y)     0; 
          0  -(b-x)     0  -(b+x)    0  b+x     0    b-x;
      -(b-x) -(h-y) -(b+x)  (h-y)  b+x  h+y   b-x  -(h+y) ]/(4*b*h);
  
% %Plane strain
% D = ((E/((1+v)*(1-2*v))))*[ 1-v  v    0;
%                              v  1-v   0;
%                              0   0  0.5-v ];
                 
                         
%Plane stress
D = E*[ 1  v    0;
        v  1    0;
        0  0 (1-v)/2 ]/(1-v^2);
              
              
ke = B.'*D*B.*t;

K = int(int(ke,x,-b,b),y,-h,h);

KK = vpa(subs(K , [E, v, t, b, h], [30*10^6, 0.25, 1, 1, 1]),5)


