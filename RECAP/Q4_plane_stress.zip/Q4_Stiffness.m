function [ K ] = Q4_Stiffness( E,C,xy,h,v,TYPE,NumEle,NumDof);
% Siffness matrix in global coordinates [Ke]=[B'][D][B]h|[J]|
%   [B] is the matrix that relates strains to displacments
%   E is modulus of elastcity of the element
%   h is the thickness of the element
%   v is Poisson's ratio

gpts = [0.0000000 -0.5773503 0.5773503 0.0000000 -0.7745967 0.7745967 -0.3399810 -0.8611363 0.3399810 0.8611363 0.0000000 -0.5384693 -0.9061798 0.5384693 0.9061798 -0.2386102 -0.6612094 -0.9324695 0.2386102 0.6612094 0.9324695 0.0000000 0.4058452 -0.4058452 -0.7415312 0.7415312 -0.9491079 0.9491079];
gwts = [2.0000000 1.0000000 1.0000000 0.8888889 0.5555556 0.5555556 0.6521452 0.3478549 0.6521452 0.3478549 0.5688889 0.4786287 0.2369269 0.4786287 0.2369269 0.4679139 0.3607616 0.1713245 0.4679139 0.3607616 0.1713245 0.4179592 0.3818301 0.3818301 0.2797054 0.2797054 0.1294850 0.1294850];

K = zeros(NumDof);

for iele = 1:NumEle
    
    switch TYPE
        case 1
            D = E(iele)/(1-v^2)*[1    v     0;
                               v    1     0;
                               0    0 (1-v)/2]; % plain stress
        case 2
            D = E(iele)/(1+v)/(1-2*v)*[1-v   v    0;
                                      v   1-v   0;
                                      0    0  .5-v];  % plain strain
    end
    
    Ke = zeros(8);
    
    npts = 7;
    if npts == 1
        gptss = gpts(1);
        gwtss = gwts(1);
    elseif npts == 2
        gptss = gpts(2:3);
        gwtss = gwts(2:3);
    elseif npts == 3
        gptss = gpts(4:6);
        gwtss = gwts(4:6);
    elseif npts == 4
        gptss = gpts(7:10);
        gwtss = gwts(7:10);
    elseif npts == 5
        gptss = gpts(11:15);
        gwtss = gwts(11:15);
    elseif npts == 6
        gptss = gpts(16:21);
        gwtss = gwts(16:21);
    else
        gptss = gpts(22:28);
        gwtss = gwts(22:28);
    end

    for iq = 1:npts
        for jq = 1:npts
            
            s  = gptss(iq);
            t  = gptss(jq);
            wt = gwtss(iq)*gwtss(jq);
            
            xeT = xy(C(iele,:),1).';
            yeT = xy(C(iele,:),2).';

%             N1 = (1-s)*(1-t)/4;
%             N2 = (1+s)*(1-t)/4;
%             N3 = (1+s)*(1+t)/4;
%             N4 = (1-s)*(1+t)/4;
% 
%             N = [ N1; N2; N3; N4 ];
% 
            dnds = [ t/4 - 1/4; 1/4 - t/4; t/4 + 1/4; - t/4 - 1/4];
            dndt = [ s/4 - 1/4; - s/4 - 1/4; s/4 + 1/4; 1/4 - s/4];

            J = [(xeT*dnds) (yeT*dnds); (xeT*dndt) (yeT*dndt)];
            detJ = det(J);

            dxds = xeT*dnds;
            dxdt = xeT*dndt;
            dyds = yeT*dnds;
            dydt = yeT*dndt;

            for im = 1:4
                b11(im) = dydt*dnds(im)-dyds*dndt(im);
                b22(im) = dxds*dndt(im)-dxdt*dnds(im);
                b32(im) = dydt*dnds(im)-dyds*dndt(im);
                iim = 2*im-1;
                
                B(1:3,iim:iim+1) = [ b11(im)    0   ;
                                     0     b22(im);
                                   b22(im) b32(im)];    
            end

            Ke = Ke + B.'*D*B/detJ*wt;            
        
        end
    end

    
    Ktemp = zeros(NumDof);
    
    for i = 1:8
        for j = 1:8
            
            if i==1 
                index1=2*C(iele,1)-1;
            elseif i==2
                index1=2*C(iele,1);
            elseif i==3
                index1=2*C(iele,2)-1;
            elseif i==4
                index1=2*C(iele,2);
            elseif i==5
                index1=2*C(iele,3)-1;
            elseif i==6
                index1=2*C(iele,3);
            elseif i==7
                index1=2*C(iele,4)-1;
            elseif i==8
                index1=2*C(iele,4);
            end
           
            if j==1 
                index2=2*C(iele,1)-1;
            elseif j==2
                index2=2*C(iele,1);
            elseif j==3
                index2=2*C(iele,2)-1;
            elseif j==4
                index2=2*C(iele,2);
            elseif j==5
                index2=2*C(iele,3)-1;
            elseif j==6
                index2=2*C(iele,3);
            elseif j==7
                index2=2*C(iele,4)-1;
            elseif j==8
                index2=2*C(iele,4);
            end       
                Ktemp(index1,index2)= Ke(i,j)*h(iele);
        end
    end
    
    K = Ktemp + K;
     
end

