function draw_patch(x,y,col,thick,col1,faceal,lineal)

if nargin==2;col=[.7 .7 .7];thick=0.5;col1='k';faceal=1;lineal=1;end
if nargin==3;thick=0.5;col1='k';faceal=1;lineal=1;end
if nargin==4;col1='k';faceal=1;lineal=1;end
if nargin==5;faceal=1;lineal=1;end
if nargin==6;lineal=1;end
if isempty(col)==1;col=[.7 .7 .7];end
patch(x,y,col,'linewidth',thick,'edgecolor',col1,'facealpha',faceal,'edgealpha',lineal);


