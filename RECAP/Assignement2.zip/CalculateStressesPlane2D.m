function stress = calculateStressesPlane2D(a,b,E,nu,thick,q,nodes,incom)


[numele i2] = size(nodes);
%calculate stresses in each element at corner points
stress = zeros(numele,4,3);

xi = [-1 1 1 -1]; eta = [-1 -1 1 1];
C = PlaneStressElastMatrix(E,nu);

loc  = zeros(8,1)
for i=1:numele
   no   = nodes(i,1:4)';
   loc(1:2:8) = 2*no-1;loc(2:2:8) = 2*no;
   d    = q(loc);
   if incom==1;d = Membrane4BIncomDof(a,b,E,nu,thick,d);end
   for i1 = 1:4
      B     = BmatrixMembrane(xi(i1),eta(i1),a,b,incom);
      stress(i,i1,:) = C * B * d;
   end   
end

