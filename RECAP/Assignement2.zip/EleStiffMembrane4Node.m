%**************************************************************************************
%8x8 ELEMENT STIFFNESS MATRIX and RESISTANCE FORCE VECTOR of 4-NODE PLANE SRESS ELEMENT
%**************************************************************************************
function [KK, QQ] = EleStiffMembrane4Node(a,b,E,nu,thick,incom,nonlinear,qq);

%a = 0.5 * length;
%b = 0.5 * height;
%nu = Poisson's ratio
%thick

%nonlinear = 1 = fully nonlinear; nonlinear = 0 = linear;
if nargin==6;qq = [];nonlinear=0;end
if nargin==7;qq = zeros(8,1);end
if nargin==5;incom=0;qq = [];nonlinear=0;end

if incom==1 & nonlinear==1;'incompatible modes not implemented for nonlinear problem';stop;end
    
%INPUT
%a:       half of element length in x-direction
%b:       half of element length in y-direction
%E:       modulus of elasticity
%nu:      POISSON's ratio
%thick:   thickness of element (out-of-plane dimension)
%incom=0: conventional formulation 
%incom=1:	formulation with incompatible modes
%flag=1:  geometrically linear formulation
%flag=2:  geometrically nonlinear formulation

%OUTPUT
%KK = 8x8 element stiffness matrix
%QQ = 8x1 nodal resisting forces



%2 GAUSS points
g(1)  =  -1 / sqrt(3);
w(1)  =  1;
g(2)  =  -g(1);
w(2)  =  1;

%Elasticity matrix
C = PlaneStressElastMatrix(E,nu);
if incom==0;
   KK            = zeros(8,8);
   QQ            = zeros(8,1);
else;
   KK            = zeros(12,12);
   QQ            = zeros(12,1);
end   

%GAUSS integration
ngauss = 2;
for   i         = 1 : ngauss
   xi = g(i);
   for j        = 1 : ngauss
      eta       = g(j);
       [B, BL, epsilon] = BmatrixMembrane(xi,eta,a,b,incom,nonlinear,qq);
       if nonlinear==1
           sigma    = C * epsilon;
           QQ       = QQ  + (B+BL)' * sigma * w(i) .* w(j);
           KK       = KK  + (B+BL)' * C * (B+BL) * w(i) .* w(j);
       else    
           KK       = KK  + B' * C * B * w(i) .* w(j);
       end
   end 
end   
KK = KK * thick * a * b;
QQ = QQ * thick * a * b;


%Static condensation to 8x8 matrix for incompatible modes
if incom==1
   dof1 = [1:8];dof2 = [9:12];
   K11  = KK(dof1,dof1);
   K12  = KK(dof1,dof2);
   K21  = KK(dof2,dof1);
   K22  = KK(dof2,dof2);
   KK   = K11 - K12*inv(K22)*K21;
end   