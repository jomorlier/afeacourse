%************************************
%CALCULATES THE 3x3 ELASTICITY MATRIX
%FOR PLANE STRESS
%************************************
function C = PlaneStressElastMatrix(E,nu);
%INPUT:
%E:        Young's modulus
%nu:       Poisson's ratio

%OUTPUT:
%C:			 3x3 elasticity matrix
  C          = zeros(3,3);
  C(1,1)     = 1;
  C(2,2)     = 1;
  C(1,2)     = nu;
  C(2,1)     = nu;
  C(3,3)     = (1 - nu) ./2;
  C          = C .* E ./ (1 - nu.^2);
  
 
