% x and y same [x,y] = gen_nodes_4node_2d(x,y,nx,ny);
%nodes is the critical informatio to draw patches

function [x,y,nodes,lines,xm,ym] = gen_grid_membrane(Lx,Ly,nx,ny);
%INPUT
%Lx:     length of rectangle in x-direction
%Ly:     length of rectangle in y-direction
%nx:     number of subdivisions in x-direction
%ny:     number of subdivisions in y-direction

%OUTPUT
%x,y:    node coordinates
%nodes:  nodes defining the elements 

numno   = (nx + 1) * (ny + 1);

delx    =  2/nx;
dely    =  2/ny;
xi      = [-1:delx:1];
eta     = [-1:dely:1];

eeta  = zeros(numno,1);
xxi   = zeros(numno,1);

cou = 1;
for j=1:ny+1
   for i=1:nx+1
      xxi(cou) = xi(i);
      eeta(cou) = eta(j);
      cou = cou + 1;
   end
end

xii   = [ -1   1  1  -1 ];
etai  = [ -1  -1  1   1 ];

N = 0.25 .* ( 1 + xxi * xii ) .* (1 + eeta * etai );

x = N * [0 Lx Lx 0]';
y = N * [0 0 Ly Ly]';

add1  = (nx + 1);
nodes = zeros(nx*ny,4);
%element counter
cou  = 1;
cou1 = 0;
for j=1:ny
   for i=1:nx
      a = [1  2  2+add1 1+add1] + i-1 + cou1;
      nodes(cou,:) = a;
      cou = cou + 1;
   end
   cou1 = cou1 + add1;
end   

%define lines: 4 lines per elements
lines = zeros(2,nx*ny*4);
cou   = 1;
for i=1:nx*ny;
    lines(1,cou:cou+3) = nodes(i,:);
    lines(2,cou:cou+3) = nodes(i,[2 3 4 1]);
    cou = cou + 4;
end   

%calculate midpoint of all elements
for i = 1:nx*ny
   xm(i) =sum(x(nodes(i,:))) / 4; ym(i) =sum(y(nodes(i,:))) / 4;
end   
 
lines = lines';

 'hallo'
 