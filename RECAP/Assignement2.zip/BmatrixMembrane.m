%**********************************************
%CALCULATES THE DISPLACEMENT-TO-STRAIN MATRIX B
%FOR A 4-node RECTANGULAR PLANE STRESS ELEMENT
%**********************************************

%INPUT: 
%xi, eta: element coordinates
%a, b:    element length and width
%incom=0: conventional formulation 
%incom=1:	formulation with incompatible modes

%OUTPUT: 
%B:       3x8 matrix
%BL:      3x8 matrix according to Taylor

function [B, BL, epsilon] = BMatrixMembrane(xi,eta,a,b,incom,nonlinear,qq);

if nargin==4;incom=0;nonlinear = 0;end
if nargin==5;nonlinear = 0;end
if nargin==6 & nonlinear == 1;'error displacements missing';end

if incom==0;
   B            = zeros(3,8);
else
   B            = zeros(3,12);
end

c1 = (1 - eta)/ a;
c2 = (1 + eta)/ a;
c3 = (1 - xi) / b;
c4 = (1 + xi) / b;

c5 = - 4*2*xi  / a^2;
c6 = - 4*2*eta / b^2;


if incom==0;
   B(1,:)  = [ -c1   0    c1   0   c2  0  -c2    0];
   B(2,:)  = [   0  -c3    0  -c4  0   c4   0   c3];
   B(3,:)  = [ -c3  -c1  -c4   c1  c4  c2  c3  -c2];
else
   B(1,:)  = [ -c1   0    c1   0   c2  0  -c2    0  c5  0   0  0];
   B(2,:)  = [   0  -c3    0  -c4  0   c4   0   c3   0  0   0  c6];
   B(3,:)  = [ -c3  -c1  -c4   c1  c4  c2  c3  -c2   0  c6  c5 0];
%   'hallo'
%   pause
end
B       = B / 4;
BL      = []; epsilon = [];

if nonlinear==1;
    G = zeros(4,8);
    %Taylor volume 2 page 303
    locx = [1:2:8];
    locy = [2:2:8];
    G(1,locx) = [-c1  c1  c2 -c2]/4;
    G(2,locy) = [-c1  c1  c2 -c2]/4;
    G(3,locx) = [-c3 -c4  c4  c3]/4;
    G(4,locy) = [-c3 -c4  c4  c3]/4;
    theta     = G * qq;
%    dudx = [-c1  c1  c2 -c2] * u;
%    dvdx = [-c1  c1  c2 -c2] * v;
%    dudy = [-c3 -c4  c4  c3] * u;
%    dvdy = [-c3 -c4  c4  c3] * v;
%    thetaxT  = [dudx dvdx];
%    thetayT  = [dudy dvdy];
%    theta    = [thetaxT' thetayT'];
 
     A       = zeros(3,4);
    A(1,1:2) = theta(1:2)';
    A(2,3:4) = theta(3:4)';
    A(3,3:4) = theta(1:2)';
    A(3,1:2) = theta(3:4)';
    BL       = A * G;
    epsilon  = 0.5 * A * theta + B * qq;
end   