%determine internal dofs with external dofs known
function q = Membrane4BIncomDof(a,b,E,nu,thick,q);
%INPUT
%a: half of element length in x-direction
%b: half of element length in y-direction
%E: modulus of elasticity
%nu: POISSON's ratio
%thick: thickness of element (out-of-plane)

%OUTPUT
%KK = 8x8 ESM

g(1)  =  -1 / sqrt(3);
w(1)  =  1;
g(2)  =  -g(1);
w(2)  =  1;

%DETERMINE ELASTICITY MATRIX
C = PlaneStressElastMatrix(E,nu);
KK            = zeros(12,12);

incom  = 1;
ngauss = 2;
for   i         = 1 : ngauss
   xi = g(i);
   for j        = 1 : ngauss
       eta      = g(j);
       B        = BmatrixMembrane(xi,eta,a,b,incom);
       KK       = KK  + B' * C * B * w(i) .* w(j);
   end 
end   
KK = KK * thick * a * b;

dof1 = [1:8];dof2 = [9:12];
K11  = KK(dof1,dof1);
K12  = KK(dof1,dof2);
K21  = KK(dof2,dof1);
K22  = KK(dof2,dof2);
%internal dofs
q2   = -inv(K22) * K21 * q;

q    = [q; q2];
   

